//Exercise9
function areaofcircle(radius) 
    {var area = Math.PI * squareNumber(radius);
    console.log('The area of circle with radius ' + radius + ' is ' + area);
    return area;}
areaofcircle(2);