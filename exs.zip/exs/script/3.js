//Exercise3
var age = 21;
var maxAge = 99;
var numbereachDay = 8;
var totalNeed = (numbereachDay * 365) * (maxAge - age);
var message = 'You will need ' + totalNeed + ' lollipop to last you until the ripe old age of ' + maxAge;
console.log(message);