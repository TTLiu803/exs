//Exercise8
function percent(num1, num2) 
    {var percented = (num1/num2) * 100;
    console.log(num1 + ' is ' + percented + '% of ' + num2);
    return percented;}
percent(2, 4);