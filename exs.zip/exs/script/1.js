//Exercise1
var money  = '$10000/month';
var Location = 'Finland';
var job = 'UV Designer';
var reason ='living';
var future = 'You will be a ' + job + ' in ' + Location + ', making ' +
   money + ' for ' + reason;
console.log(future);