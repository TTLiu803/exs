//Exercise6
function squareNumber(num) 
    {var squaredNumber = num * num;
    
    console.log('The result of squaring the number ' + num + ' is ' + squaredNumber);
    return squaredNumber;}
squareNumber(3);