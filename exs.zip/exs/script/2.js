//Exercise2
var birthYear = 1999;
var futureYear  = 2020;
var age  = futureYear - birthYear;
console.log('They are ' + age +'years old');