//Exercise10
function runall(num) 
    {var half    = halfof(num);
    var squared = squarenumber(half);
    var area    = areaofcircle(squared);
    var result  = percentof(squared, area);}
runall(5);