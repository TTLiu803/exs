//Exercise7
function half(num) 
    {var halfed = num / 2;
    console.log('Half of ' + num + ' is ' +  halfed);
    return halfed;}
halfOf(5);